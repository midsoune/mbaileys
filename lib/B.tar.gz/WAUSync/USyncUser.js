"use strict"

Object.defineProperty(exports, "__esModule", { value: true })

class USyncUser {
    withId(id) {
        this.id = id
        return this
    }
    withUsername(username) {
        this.username = username
        return this
    }
    withUsernameKey(usernameKey) {
        this.usernameKey = usernameKey
        return this
    }
    withLid(lid) {
        this.lid = lid
        return this
    }
    withPhone(phone) {
        this.phone = phone
        return this
    }
    withType(type) {
        this.type = type
        return this
    }
    withPersonaId(personaId) {
    	this.personaId = personaId
        return this
    }
}

module.exports = {
  USyncUser
}