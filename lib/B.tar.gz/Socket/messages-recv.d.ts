import { Boom } from '@hapi/boom'
import { proto } from '../../WAProto'
import { MessageReceiptType, MessageRelayOptions, SocketConfig, WAMessageKey, ContactAction, WAInitiateCallOptions, WAInitiateCallResult, WACallParticipant } from '../Types'
import { BinaryNode } from '../WABinary'

export declare const makeMessagesRecvSocket: (config: SocketConfig) => {
    sendMessageAck: ({ tag, attrs, content }: BinaryNode, errorCode?: number) => Promise<void>
    sendRetryRequest: (node: BinaryNode, forceIncludeKeys?: boolean) => Promise<void>
    offerCall: (toJid: string, isVideo?: boolean) => Promise<{
        id: any
        to: string
    }>
    initiateCall: (jid: string, options?: WAInitiateCallOptions) => Promise<WAInitiateCallResult>
    initiateCalls: (requests: Array<{ jid: string; options?: WAInitiateCallOptions }>) => Promise<any[]>
    getActiveCalls: () => Promise<import('../Voip').CallSummary[]>
    getCall: (callId: string) => Promise<import('../Voip').ActiveCall | undefined>
    getActiveCallCount: () => Promise<number>
    endCall: (callId: string) => Promise<void>
    endAllCalls: () => Promise<void>
    setVoipOptions: (options: import('../Voip').VoipConfigOptions) => Promise<void>
    cancelCall: (callId: string, callTo: string) => Promise<void>
    rejectCall: (callId: string, callFrom?: string, reason?: string) => Promise<void>
    acceptCall: (callId: string, callFromOrOptions?: string | { isVideo?: boolean; audio?: string; audioSource?: string; [key: string]: any }, isVideo?: boolean, options?: any) => Promise<any>
    preacceptCall: (callId: string, callCreator: string, isVideo?: boolean) => Promise<void>
    getVoipClient: () => Promise<import('../Voip').VoipClient>
    getVoipMemoryStats: () => Promise<any>
    terminateCall: (callId: string, callTo: string, callCreator?: string, reason?: string, duration?: number) => Promise<void>
    sendRelayLatency: (callId: string, callCreator: string, relays: Array<{ relayName?: string; latency: number; relayId?: string; dlBw?: number; ulBw?: number }>, transactionId?: string) => Promise<void>
    sendTransport: (callId: string, callCreator: string, to: string, candidates: Array<{ priority: string; data?: Uint8Array }>, round?: number) => Promise<void>
    sendCallDuration: (callId: string, callCreator: string, peer: string, audioDuration: number, callType?: string) => Promise<void>
    muteCall: (callId: string, callCreatorOrMuted?: string | boolean, to?: string, muted?: boolean) => Promise<void>
    unmuteCall: (callId: string, callCreator?: string, to?: string) => Promise<void>
    sendHeartbeat: (callId: string, callCreator: string) => Promise<void>
    sendEncRekey: (callId: string, callCreator: string, to: string, transactionId: string) => Promise<void>
    sendVideoState: (callId: string, callCreator: string, to: string, enabled: boolean, orientation?: string) => Promise<void>
    queryCallLink: (token: string, media?: 'video' | 'audio') => Promise<BinaryNode>
    joinCallLink: (token: string, media?: 'video' | 'audio') => Promise<BinaryNode>
    fetchMessageHistory: (count: number, oldestMsgKey: WAMessageKey, oldestMsgTimestamp: number | Long) => Promise<string>
    requestPlaceholderResend: (messageKey: WAMessageKey) => Promise<string | undefined>
    getPrivacyTokens: (jids: string[]) => Promise<BinaryNode>
    assertSessions: (jids: string[], force: boolean) => Promise<boolean>
    relayMessage: (jid: string, message: proto.IMessage, { messageId: msgId, participant, additionalAttributes, additionalNodes, useUserDevicesCache, useCachedGroupMetadata, statusJidList }: MessageRelayOptions) => Promise<string>
    sendReceipt: (jid: string, participant: string | undefined, messageIds: string[], type: MessageReceiptType) => Promise<void>
    sendReceipts: (keys: proto.IMessageKey[], type: MessageReceiptType) => Promise<void>
    readMessages: (keys: proto.IMessageKey[]) => Promise<void>
    refreshMediaConn: (forceGet?: boolean) => Promise<import("../Types").MediaConnInfo>
    waUploadToServer: import("../Types").WAMediaUploadFunction
    fetchPrivacySettings: (force?: boolean) => Promise<{
        [_: string]: string
    }>
    sendPeerDataOperationMessage: (pdoMessage: proto.Message.IPeerDataOperationRequestMessage) => Promise<string>
    createParticipantNodes: (jids: string[], message: proto.IMessage, extraAttrs?: {
        [key: string]: string
    } | undefined) => Promise<{
        nodes: BinaryNode[]
        shouldIncludeDeviceIdentity: boolean
    }>
    profilePictureUrl: (jid: string) => Promise<string>
    getUSyncDevices: (jids: string[], useCache: boolean, ignoreZeroDevices: boolean) => Promise<import("../WABinary").JidWithDevice[]>
    getEphemeralGroup: (jid: string) => Promise<number>
    updateMediaMessage: (message: proto.IWebMessageInfo) => Promise<proto.IWebMessageInfo>
    sendStatusMentions: (content: import("../Types").WAProto.IMessage, jid: string, Private?: boolean) => Promise<string>
    sendMessage: (jid: string, content: import("../Types").AnyMessageContent, options?: import("../Types").MiscMessageGenerationOptions) => Promise<proto.WebMessageInfo | undefined>
    subscribeNewsletterUpdates: (jid: string) => Promise<{
        duration: string
    }>
    newsletterReactionMode: (jid: string, mode: import("../Types").NewsletterReactionMode) => Promise<void>
    newsletterUpdateDescription: (jid: string, description?: string | undefined) => Promise<void>
    newsletterUpdateName: (jid: string, name: string) => Promise<void>
    newsletterUpdatePicture: (jid: string, content: import("../Types").WAMediaUpload) => Promise<void>
    newsletterRemovePicture: (jid: string) => Promise<void>
    newsletterUnfollow: (jid: string) => Promise<void>
    newsletterFollow: (jid: string) => Promise<void>
    newsletterUnmute: (jid: string) => Promise<void>
    newsletterMute: (jid: string) => Promise<void>
    newsletterCreate: (name: string, description?: string, picture?: import("../Types").WAMediaUpload) => Promise<import("../Types").NewsletterMetadata>
    newsletterQuery: (jid: string, type: string, content: BinaryNode) => Promise<BinaryNode>
    newsletterWMexQuery: (jid?: string | undefined, query_id: number, content: BinaryNode) => Promise<BinaryNode>
    newsletterMetadata: (type: "invite" | "jid", key: string, role?: import("../Types").NewsletterViewRole | undefined) => Promise<import("../Types").NewsletterMetadata>
    newsletterFetchAllParticipating: () => Promise<{
        [_: string]: import("../Types").NewsletterMetadata
    }>
    newsletterAdminCount: (jid: string) => Promise<number>
    newsletterChangeOwner: (jid: string, userLid: string) => Promise<void>
    newsletterDemote: (jid: string, userLid: string) => Promise<void>
    newsletterDelete: (jid: string) => Promise<void>
    newsletterReactMessage: (jid: string, server_id: string, code?: string | undefined) => Promise<void>
    newsletterFetchMessages: (type: "invite" | "jid", key: string, count: number, after?: number | undefined) => Promise<import("../Types").NewsletterFetchedUpdate[]>
    newsletterFetchUpdates: (jid: string, count: number, after?: number | undefined, since?: number | undefined) => Promise<import("../Types").NewsletterFetchedUpdate[]>
    groupQuery: (jid: string, type: string, content: BinaryNode) => Promise<BinaryNode>
    groupMetadata: (jid: string) => Promise<import("../Types").GroupMetadata>
    groupCreate: (subject: string, participants: string[]) => Promise<import("../Types").GroupMetadata>
    groupLeave: (id: string) => Promise<void>
    groupUpdateSubject: (jid: string, subject: string) => Promise<void>
    groupRequestParticipantsList: (jid: string) => Promise<{
        [key: string]: string
    }[]>
    groupRequestParticipantsUpdate: (jid: string, participants: string[], action: "reject" | "approve") => Promise<{
        status: string
        jid: string
    }[]>
    groupParticipantsUpdate: (jid: string, participants: string[], action: import("../Types").ParticipantAction) => Promise<{
        status: string
        jid: string
        content: BinaryNode
    }[]>
    groupUpdateDescription: (jid: string, description?: string | undefined) => Promise<void>
    groupInviteCode: (jid: string) => Promise<string | undefined>
    groupRevokeInvite: (jid: string) => Promise<string | undefined>
    groupAcceptInvite: (code: string) => Promise<string | undefined>
    groupRevokeInviteV4: (groupJid: string, invitedJid: string) => Promise<boolean>
    groupAcceptInviteV4: (key: string | proto.IMessageKey, inviteMessage: proto.Message.IGroupInviteMessage) => Promise<string>
    groupGetInviteInfo: (code: string) => Promise<import("../Types").GroupMetadata>
    groupToggleEphemeral: (jid: string, ephemeralExpiration: number) => Promise<void>
    groupSettingUpdate: (jid: string, setting: "announcement" | "locked" | "not_announcement" | "unlocked") => Promise<void>
    groupMemberAddMode: (jid: string, mode: "all_member_add" | "admin_add") => Promise<void>
    groupJoinApprovalMode: (jid: string, mode: "on" | "off") => Promise<void>
    groupFetchAllParticipating: () => Promise<{
        [_: string]: import("../Types").GroupMetadata
    }>
    processingMutex: {
        mutex<T>(code: () => T | Promise<T>): Promise<T>
    }
    upsertMessage: (msg: proto.IWebMessageInfo, type: import("../Types").MessageUpsertType) => Promise<void>
    appPatch: (patchCreate: import("../Types").WAPatchCreate) => Promise<void>
    createCallLink: (type: 'audio' | 'video', event?: number, timeoutMs?: number) => Promise<void>
    sendPresenceUpdate: (type: import("../Types").WAPresence, toJid?: string | undefined, options?: { simulateTyping?: boolean; typingDuration?: number }) => Promise<void>
    presenceSubscribe: (toJid: string, tcToken?: Buffer | undefined) => Promise<void>
    getLidUser: (jid: string) => Promise<{
        lid: string
        id: string
    }[] | undefined>
    fetchBlocklist: () => Promise<string[]>
    fetchStatus: (...jids: string[]) => Promise<import("..").USyncQueryResultList[] | undefined>
    fetchDisappearingDuration: (...jids: string[]) => Promise<import("..").USyncQueryResultList[] | undefined>
    updateProfilePicture: (jid: string, content: import("../Types").WAMediaUpload) => Promise<void>
    removeProfilePicture: (jid: string) => Promise<void>
    updateProfileStatus: (status: string) => Promise<void>
    updateProfileName: (name: string) => Promise<void>
    updateBlockStatus: (jid: string, action: "block" | "unblock") => Promise<void>
    updateCallPrivacy: (value: import("../Types").WAPrivacyCallValue) => Promise<void>
    updateLastSeenPrivacy: (value: import("../Types").WAPrivacyValue) => Promise<void>
    updateOnlinePrivacy: (value: import("../Types").WAPrivacyOnlineValue) => Promise<void>
    updateProfilePicturePrivacy: (value: import("../Types").WAPrivacyValue) => Promise<void>
    updateStatusPrivacy: (value: import("../Types").WAPrivacyValue) => Promise<void>
    updateReadReceiptsPrivacy: (value: import("../Types").WAReadReceiptsValue) => Promise<void>
    updateGroupsAddPrivacy: (value: import("../Types").WAPrivacyGroupAddValue) => Promise<void>
    updateDefaultDisappearingMode: (duration: number) => Promise<void>
    updateDisableLinkPreviewsPrivacy: (isPreviewsDisabled: boolean) => Promise<void>
    getBusinessProfile: (jid: string) => Promise<void | import("../Types").WABusinessProfile>
    resyncAppState: (collections: readonly ("critical_block" | "critical_unblock_low" | "regular_high" | "regular_low" | "regular")[], isInitialSync: boolean) => Promise<void>
    chatModify: (mod: import("../Types").ChatModification, jid: string) => Promise<void>
    cleanDirtyBits: (type: "account_sync" | "groups", fromTimestamp?: string | number | undefined) => Promise<void>
    addLabel: (jid: string, labels: import("../Types/Label").LabelActionBody) => Promise<void>
    addChatLabel: (jid: string, labelId: string) => Promise<void>
    removeChatLabel: (jid: string, labelId: string) => Promise<void>
    addMessageLabel: (jid: string, messageId: string, labelId: string) => Promise<void>
    removeMessageLabel: (jid: string, messageId: string, labelId: string) => Promise<void>
    clearMessage: (jid: string, key: import("../Types").WAProto.IMessageKey, timeStamp: number | import("long").Long) => Promise<void>
    star: (jid: string, messages: {
        id: string
        fromMe?: boolean | undefined
    }[], star: boolean) => Promise<void>
    addOrEditQuickReply: (quickReply: import("../Types/Bussines").QuickReplyAction) => Promise<void>
    removeQuickReply: (timestamp: string) => Promise<void>
    addOrEditContact: (jid: string, contact: ContactAction) => Promise<void>
    removeContact: (jid: string) => Promise<void>
    executeUSyncQuery: (usyncQuery: import("..").USyncQuery) => Promise<import("..").USyncQueryResult | undefined>
    type: "md"
    ws: import("./Client").WebSocketClient
    ev: import("../Types").BaileysEventEmitter & {
        process(handler: (events: Partial<import("../Types").BaileysEventMap>) => void | Promise<void>): () => void
        buffer(): void
        createBufferedFunction<A extends any[], T_1>(work: (...args: A) => Promise<T_1>): (...args: A) => Promise<T_1>
        flush(force?: boolean | undefined): boolean
        isBuffering(): boolean
    }
    authState: {
        creds: import("../Types").AuthenticationCreds
        keys: import("../Types").SignalKeyStoreWithTransaction
    }
    signalRepository: import("../Types").SignalRepository
    user: import("../Types").Contact | undefined
    generateMessageTag: () => string
    query: (node: BinaryNode, timeoutMs?: number | undefined) => Promise<BinaryNode>
    waitForMessage: <T_2>(msgId: string, timeoutMs?: number | undefined) => Promise<T_2>
    waitForSocketOpen: () => Promise<void>
    sendRawMessage: (data: Uint8Array | Buffer) => Promise<void>
    sendNode: (frame: BinaryNode) => Promise<void>
    logout: (msg?: string | undefined) => Promise<void>
    end: (error: Error | undefined) => void
    onUnexpectedError: (err: Error | Boom<any>, msg: string) => void
    uploadPreKeys: (count?: number) => Promise<void>
    uploadPreKeysToServerIfRequired: () => Promise<void>
    requestPairingCode: (phoneNumber: string, code?: string) => Promise<string>
    waitForConnectionUpdate: (check: (u: Partial<import("../Types").ConnectionState>) => boolean | undefined, timeoutMs?: number | undefined) => Promise<void>
    sendWAMBuffer: (wamBuffer: Buffer) => Promise<BinaryNode>
}