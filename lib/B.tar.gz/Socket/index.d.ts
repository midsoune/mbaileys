import { UserFacingSocketConfig, ContactAction } from '../Types'

declare const makeWASocket: (config: UserFacingSocketConfig) => {
    logger: import("../Utils/logger").ILogger
    getOrderDetails: (orderId: string, tokenBase64: string) => Promise<import("../Types").OrderDetails>
    getCatalog: ({ jid, limit, cursor }: import("../Types").GetCatalogOptions) => Promise<{
        products: import("../Types").Product[]
        nextPageCursor: string | undefined
    }>
    getCollections: (jid?: string | undefined, limit?: number) => Promise<{
        collections: import("../Types").CatalogCollection[]
    }>
    productCreate: (create: import("../Types").ProductCreate) => Promise<import("../Types").Product>
    productDelete: (productIds: string[]) => Promise<{
        deleted: number
    }>
    productUpdate: (productId: string, update: import("../Types").ProductUpdate) => Promise<import("../Types").Product>
    updateBussinesProfile: (args: import("../Types").UpdateBussinesProfileProps) => Promise<any>
    updateCoverPhoto: (photo: import("../Types").WAMediaUpload) => Promise<number>
    removeCoverPhoto: (id: string) => Promise<any>
    sendMessageAck: ({ tag, attrs, content }: import("..").BinaryNode, errorCode?: number | undefined) => Promise<void>
    sendRetryRequest: (node: import("..").BinaryNode, forceIncludeKeys?: boolean) => Promise<void>
    offerCall: (toJid: string, isVideo?: boolean) => Promise<{
        id: any
        to: string
    }>
    initiateCall: (jid: string, options?: import('../Types').WAInitiateCallOptions) => Promise<import('../Types').WAInitiateCallResult>
    initiateCalls: (requests: Array<{ jid: string; options?: import('../Types').WAInitiateCallOptions }>) => Promise<any[]>
    getActiveCalls: () => Promise<import('../Voip').CallSummary[]>
    getCall: (callId: string) => Promise<import('../Voip').ActiveCall | undefined>
    getActiveCallCount: () => Promise<number>
    endCall: (callId: string) => Promise<void>
    endAllCalls: () => Promise<void>
    setVoipOptions: (options: import('../Voip').VoipConfigOptions) => Promise<void>
    rejectCall: (callId: string, callFrom?: string, reason?: string) => Promise<void>
    acceptCall: (callId: string, callFromOrOptions?: string | { isVideo?: boolean; audio?: string; audioSource?: string; [key: string]: any }, isVideo?: boolean, options?: any) => Promise<any>
    preacceptCall: (callId: string, callCreator: string, isVideo?: boolean) => Promise<void>
    muteCall: (callId: string, callCreatorOrMuted?: string | boolean, to?: string, muted?: boolean) => Promise<void>
    unmuteCall: (callId: string, callCreator?: string, to?: string) => Promise<void>
    getVoipClient: () => Promise<import('../Voip').VoipClient>
    getVoipMemoryStats: () => Promise<any>
    fetchMessageHistory: (count: number, oldestMsgKey: import("../Types").WAProto.IMessageKey, oldestMsgTimestamp: number | import("long").Long) => Promise<string>
    requestPlaceholderResend: (messageKey: import("../Types").WAProto.IMessageKey) => Promise<string | undefined>
    getPrivacyTokens: (jids: string[]) => Promise<import("..").BinaryNode>
    assertSessions: (jids: string[], force: boolean) => Promise<boolean>
    relayMessage: (jid: string, message: import("../Types").WAProto.IMessage, { messageId: msgId, participant, additionalAttributes, additionalNodes, useUserDevicesCache, useCachedGroupMetadata, statusJidList }: import("../Types").MessageRelayOptions) => Promise<string>
    sendReceipt: (jid: string, participant: string | undefined, messageIds: string[], type: import("../Types").MessageReceiptType) => Promise<void>
    sendReceipts: (keys: import("../Types").WAProto.IMessageKey[], type: import("../Types").MessageReceiptType) => Promise<void>
    readMessages: (keys: import("../Types").WAProto.IMessageKey[]) => Promise<void>
    refreshMediaConn: (forceGet?: boolean) => Promise<import("../Types").MediaConnInfo>
    waUploadToServer: import("../Types").WAMediaUploadFunction
    fetchPrivacySettings: (force?: boolean) => Promise<{
        [_: string]: string
    }>
    sendPeerDataOperationMessage: (pdoMessage: import("../Types").WAProto.Message.IPeerDataOperationRequestMessage) => Promise<string>
    createParticipantNodes: (jids: string[], message: import("../Types").WAProto.IMessage, extraAttrs?: {
        [key: string]: string
    } | undefined) => Promise<{
        nodes: import("..").BinaryNode[]
        shouldIncludeDeviceIdentity: boolean
    }>
    profilePictureUrl: (jids: string) => Promise<string>
    getUSyncDevices: (jids: string[], useCache: boolean, ignoreZeroDevices: boolean) => Promise<import("..").JidWithDevice[]>
    getEphemeralGroup: (jid: string) => Promise<number>
    updateMediaMessage: (message: import("../Types").WAProto.IWebMessageInfo) => Promise<import("../Types").WAProto.IWebMessageInfo>
    sendStatusMentions: (content: import("../Types").WAProto.IMessage, jid: string, Private?: boolean) => Promise<string>
    sendTable: (jid: string, title: string, headers: string[], rows: string[][], quoted?: any, options?: { headerText?: string, footer?: string }) => Promise<{ message: import("../Types").WAProto.IMessage, messageId: string }>
    sendList: (jid: string, title: string, items: string[] | string[][], quoted?: any, options?: { headerText?: string, footer?: string }) => Promise<{ message: import("../Types").WAProto.IMessage, messageId: string }>
    sendCodeBlock: (jid: string, code: string, quoted?: any, options?: { title?: string, footer?: string, language?: string }) => Promise<{ message: import("../Types").WAProto.IMessage, messageId: string }>
    sendMarkdown: (jid: string, text: string, quoted?: any, options?: { botJid?: string, mentions?: string[], extract?: boolean, hyperlink?: boolean, citation?: boolean, latex?: boolean }) => Promise<{ message: import("../Types").WAProto.IMessage, messageId: string }>
    sendLatexImage: (jid: string, quoted?: any, options?: string | { text?: string, expressions?: import("../Utils/message-composer").LatexExpression[], headerText?: string, footer?: string, caption?: string }, renderLatexToPng?: any, uploadFn?: any) => Promise<any>
    sendLatexInlineImage: (jid: string, quoted?: any, options?: string | { text?: string, expressions?: import("../Utils/message-composer").LatexExpression[], headerText?: string, footer?: string }, renderLatexToPng?: any, uploadFn?: any) => Promise<any>
    sendRichMessage: (jid: string, submessages: any[], quoted?: any, options?: { botJid?: string, mentions?: string[], useMarkdown?: boolean, unifiedResponse?: any, extract?: boolean, hyperlink?: boolean, citation?: boolean, latex?: boolean }) => Promise<{ message: import("../Types").WAProto.IMessage, messageId: string }>
    sendRichHtml: (jid: string, options: string | { id?: string, title?: string, html: string, source?: string, trusted_sources?: string | string[], typename?: string, headerText?: string, footer?: string, botJid?: string, mentions?: string[] }, quoted?: any, additionalOptions?: any) => Promise<{ message: import("../Types").WAProto.IMessage, messageId: string }>
    captureUnifiedResponse: (message: import("../Types").WAProto.IMessage) => { unifiedResponse: { data: Buffer }, submessages: any[], contextInfo: any } | null
    sendMessage: (jid: import("../Types").MessageTarget, content: import("../Types").AnyMessageContent, options?: import("../Types").MiscMessageGenerationOptions) => Promise<import("../Types").WAProto.WebMessageInfo | undefined>
    resolveUsername: (username: string) => Promise<import("../Types").UsernameResolutionResult | null>
    resolveUsernames: (usernames: string[]) => Promise<(import("../Types").UsernameResolutionResult | null)[]>
    onWhatsAppUsername: (...usernames: string[]) => Promise<import("../Types").UsernameResolutionResult[]>
    invalidateUsername: (username: string) => Promise<void>
    refreshUsername: (username: string) => Promise<import("../Types").UsernameResolutionResult | null>
    checkUsername: (username: string, includeSuggestions?: boolean) => Promise<{
        available: boolean
        username: string
        suggestions?: string[]
        rejectionReasons?: string[]
        suggestionsEligible?: boolean
    }>
    checkUsernameMulti: (usernames: string[]) => Promise<any>
    setUsername: (username: string, options?: {
        source?: 'FB' | 'IG' | 'USER_INPUT' | 'SUGGESTION'
        sessionId?: string
        pin?: string
    }) => Promise<any>
    deleteUsername: () => Promise<any>
    getMyUsername: () => Promise<string | null>
    getUsernameRecommendations: (source?: string | null) => Promise<any>
    setUsernamePin: (pin: string | null) => Promise<any>
    findUserByUsername: (username: string, pin?: string) => Promise<{
        jid: string
        contact: boolean
    } | null>
    fetchContactUsernames: (...jids: string[]) => Promise<{
        id: string
        username: string | null
    }[]>
    USERNAME_QUERY_IDS: {
        CHECK: string
        CHECK_MULTI: string
        SET: string
        GET: string
        GET_RECOMMENDATIONS: string
        PIN_SET: string
    }
    USERNAME_CHECK_RESULT: {
        SUCCESS: string
        INVALID: string
    }
    USERNAME_SOURCE: {
        FB: string
        IG: string
        USER_INPUT: string
        SUGGESTION: string
    }
    subscribeNewsletterUpdates: (jid: string) => Promise<{
        duration: string
    }>
    newsletterReactionMode: (jid: string, mode: import("../Types").NewsletterReactionMode) => Promise<void>
    newsletterUpdateDescription: (jid: string, description?: string | undefined) => Promise<void>
    newsletterUpdateName: (jid: string, name: string) => Promise<void>
    newsletterUpdatePicture: (jid: string, content: import("../Types").WAMediaUpload) => Promise<void>
    newsletterRemovePicture: (jid: string) => Promise<void>
    newsletterUnfollow: (jid: string) => Promise<void>
    newsletterFollow: (jid: string) => Promise<void>
    newsletterUnmute: (jid: string) => Promise<void>
    newsletterMute: (jid: string) => Promise<void>
    newsletterCreate: (name: string, description?: string, picture?: import("../Types").WAMediaUpload) => Promise<import("../Types").NewsletterMetadata>
    newsletterQuery: (jid: string, type: string, content: BinaryNode) => Promise<BinaryNode>
    newsletterWMexQuery: (jid?: string | undefined, query_id: number, content: BinaryNode) => Promise<BinaryNode>
    newsletterMetadata: (type: "invite" | "jid", key: string, role?: import("../Types").NewsletterViewRole | undefined) => Promise<import("../Types").NewsletterMetadata>
    newsletterFetchAllParticipating: () => Promise<{
    	[_: string]: import("../Types").NewsletterMetadata
    }>
    newsletterAdminCount: (jid: string) => Promise<number>
    newsletterChangeOwner: (jid: string, userLid: string) => Promise<void>
    newsletterDemote: (jid: string, userLid: string) => Promise<void>
    newsletterDelete: (jid: string) => Promise<void>
    newsletterReactMessage: (jid: string, server_id: string, code?: string | undefined) => Promise<void>
    newsletterFetchMessages: (type: "invite" | "jid", key: string, count: number, after?: number | undefined) => Promise<import("../Types").NewsletterFetchedUpdate[]>
    newsletterFetchUpdates: (jid: string, count: number, after?: number | undefined, since?: number | undefined) => Promise<import("../Types").NewsletterFetchedUpdate[]>
    groupQuery: (jid: string, type: string, content: BinaryNode) => Promise<BinaryNode>
    groupMetadata: (jid: string) => Promise<import("../Types").GroupMetadata>
    groupCreate: (subject: string, participants: string[]) => Promise<import("../Types").GroupMetadata>
    groupLeave: (id: string) => Promise<void>
    groupUpdateSubject: (jid: string, subject: string) => Promise<void>
    groupRequestParticipantsList: (jid: string) => Promise<{
        [key: string]: string
    }[]>
    groupRequestParticipantsUpdate: (jid: string, participants: string[], action: "reject" | "approve") => Promise<{
        status: string
        jid: string
    }[]>
    groupParticipantsUpdate: (jid: string, participants: string[], action: import("../Types").ParticipantAction) => Promise<{
        status: string
        jid: string
        content: import("..").BinaryNode
    }[]>
    groupUpdateDescription: (jid: string, description?: string | undefined) => Promise<void>
    groupInviteCode: (jid: string) => Promise<string | undefined>
    groupRevokeInvite: (jid: string) => Promise<string | undefined>
    groupAcceptInvite: (code: string) => Promise<string | undefined>
    groupRevokeInviteV4: (groupJid: string, invitedJid: string) => Promise<boolean>
    groupAcceptInviteV4: (key: string | import("../Types").WAProto.IMessageKey, inviteMessage: import("../Types").WAProto.Message.IGroupInviteMessage) => Promise<string>
    groupGetInviteInfo: (code: string) => Promise<import("../Types").GroupMetadata>
    groupToggleEphemeral: (jid: string, ephemeralExpiration: number) => Promise<void>
    groupSettingUpdate: (jid: string, setting: "announcement" | "locked" | "not_announcement" | "unlocked") => Promise<void>
    groupMemberAddMode: (jid: string, mode: "all_member_add" | "admin_add") => Promise<void>
    groupJoinApprovalMode: (jid: string, mode: "on" | "off") => Promise<void>
    groupFetchAllParticipating: () => Promise<{
        [_: string]: import("../Types").GroupMetadata
    }>
    processingMutex: {
        mutex<T>(code: () => T | Promise<T>): Promise<T>
    }
    upsertMessage: (msg: import("../Types").WAProto.IWebMessageInfo, type: import("../Types").MessageUpsertType) => Promise<void>
    appPatch: (patchCreate: import("../Types").WAPatchCreate) => Promise<void>
    createCallLink: (type: 'audio' | 'video', event?: number, timeoutMs?: number) => Promise<void>
    sendPresenceUpdate: (type: import("../Types").WAPresence, toJid?: string | undefined, options?: { simulateTyping?: boolean; typingDuration?: number }) => Promise<void>
    presenceSubscribe: (toJid: string, tcToken?: Buffer | undefined) => Promise<void>    
    getBotListV2: () => Promise<BotListInfo[]>
    getLidUser: (jid: string) => Promise<{
    	lid: string
        id: string
    }[] | undefined>
    fetchBlocklist: () => Promise<string[]>
    fetchStatus: (...jids: string[]) => Promise<import("..").USyncQueryResultList[] | undefined>
    fetchDisappearingDuration: (...jids: string[]) => Promise<import("..").USyncQueryResultList[] | undefined>
    updateProfilePicture: (jid: string, content: import("../Types").WAMediaUpload) => Promise<void>
    removeProfilePicture: (jid: string) => Promise<void>
    updateProfileStatus: (status: string) => Promise<void>
    updateProfileName: (name: string) => Promise<void>
    updateBlockStatus: (jid: string, action: "block" | "unblock") => Promise<void>
    updateCallPrivacy: (value: import("../Types").WAPrivacyCallValue) => Promise<void>
    updateLastSeenPrivacy: (value: import("../Types").WAPrivacyValue) => Promise<void>
    updateOnlinePrivacy: (value: import("../Types").WAPrivacyOnlineValue) => Promise<void>
    updateProfilePicturePrivacy: (value: import("../Types").WAPrivacyValue) => Promise<void>
    updateStatusPrivacy: (value: import("../Types").WAPrivacyValue) => Promise<void>
    updateReadReceiptsPrivacy: (value: import("../Types").WAReadReceiptsValue) => Promise<void>
    updateGroupsAddPrivacy: (value: import("../Types").WAPrivacyGroupAddValue) => Promise<void>
    updateDefaultDisappearingMode: (duration: number) => Promise<void>
    updateDisableLinkPreviewsPrivacy: (isPreviewsDisabled: boolean) => Promise<void>
    getBusinessProfile: (jid: string) => Promise<void | import("../Types").WABusinessProfile>
    resyncAppState: (collections: readonly ("critical_block" | "critical_unblock_low" | "regular_high" | "regular_low" | "regular")[], isInitialSync: boolean) => Promise<void>
    chatModify: (mod: import("../Types").ChatModification, jid: string) => Promise<void>
    cleanDirtyBits: (type: "account_sync" | "groups", fromTimestamp?: string | number | undefined) => Promise<void>
    addLabel: (jid: string, labels: import("../Types/Label").LabelActionBody) => Promise<void>
    addChatLabel: (jid: string, labelId: string) => Promise<void>
    removeChatLabel: (jid: string, labelId: string) => Promise<void>
    addMessageLabel: (jid: string, messageId: string, labelId: string) => Promise<void>
    removeMessageLabel: (jid: string, messageId: string, labelId: string) => Promise<void>
    clearMessage: (jid: string, key: import("../Types").WAProto.IMessageKey, timeStamp: number | import("long").Long) => Promise<void>
    star: (jid: string, messages: {
        id: string
        fromMe?: boolean | undefined
    }[], star: boolean) => Promise<void>
    addOrEditQuickReply: (quickReply: import("../Types/Bussines").QuickReplyAction) => Promise<void>
    removeQuickReply: (timestamp: string) => Promise<void>
    addOrEditContact: (jid: string, contact: ContactAction) => Promise<void>
    removeContact: (jid: string) => Promise<void>
    executeUSyncQuery: (usyncQuery: import("..").USyncQuery) => Promise<import("..").USyncQueryResult | undefined>
    type: "md"
    ws: import("./Client").WebSocketClient
    ev: import("../Types").BaileysEventEmitter & {
        process(handler: (events: Partial<import("../Types").BaileysEventMap>) => void | Promise<void>): () => void
        buffer(): void
        createBufferedFunction<A extends any[], T_1>(work: (...args: A) => Promise<T_1>): (...args: A) => Promise<T_1>
        flush(force?: boolean | undefined): boolean
        isBuffering(): boolean
    }
    authState: {
        creds: import("../Types").AuthenticationCreds
        keys: import("../Types").SignalKeyStoreWithTransaction
    }
    signalRepository: import("../Types").SignalRepository
    user: import("../Types").Contact | undefined
    generateMessageTag: () => string
    query: (node: import("..").BinaryNode, timeoutMs?: number | undefined) => Promise<import("..").BinaryNode>
    waitForMessage: <T_2>(msgId: string, timeoutMs?: number | undefined) => Promise<T_2>
    waitForSocketOpen: () => Promise<void>
    sendRawMessage: (data: Uint8Array | Buffer) => Promise<void>
    sendNode: (frame: import("..").BinaryNode) => Promise<void>
    logout: (msg?: string | undefined) => Promise<void>
    end: (error: Error | undefined) => void
    onUnexpectedError: (err: Error | import("@hapi/boom").Boom<any>, msg: string) => void
    uploadPreKeys: (count?: number) => Promise<void>
    uploadPreKeysToServerIfRequired: () => Promise<void>
    requestPairingCode: (phoneNumber: string, code?: string) => Promise<string>
    waitForConnectionUpdate: (check: (u: Partial<import("../Types").ConnectionState>) => boolean | undefined, timeoutMs?: number | undefined) => Promise<void>
    sendWAMBuffer: (wamBuffer: Buffer) => Promise<import("..").BinaryNode>
}

export default makeWASocket